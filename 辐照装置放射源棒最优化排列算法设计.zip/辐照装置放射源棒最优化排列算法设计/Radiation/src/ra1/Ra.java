﻿package ra1;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Random;


class Common{
	public static int L=45;		//源棒长度
	public static int M=40;		//源棒可插位置数
	public static int N=16;		//源棒个数
	public static int zone=4;		//源棒区域（共分上下两层，每层两个区域） 
	public static int sgap=5;		//同一层源棒之间的间距
	public static int lgap=100;		//源棒上下两层之间的间距
	public static int zoneCount=10;		//源棒每个区域的可插位置数
	public static int objectL=60;		//物体长度
	public static int objectH=200;		//物体高度
	public static int objectW=40;		//物体宽度
	public static int P=441;			//质点个数21*7*3 
	public static int row=21;			//物体行数
	public static int col=7;			//物体列数
	public static int ogap=10;			//物体所处的位置之间的间距
	public static int pgap=10;			//质点间距
	public static int oloc=16;			//物体可移动的位置数
}

class Source{
	private double A;			//源棒能量
	private int x;			//源棒x坐标
	private int y;			//源棒y坐标
	private int z;			//源棒z坐标
	private int location;	//源棒位置
	public Source() {
		x=0;
		y=0;
		z=0;
	}
	public void setA(double a) {
		A = a;
	}
	public void setX(int x) {
		this.x = x;
	}
	public void setY(int y) {
		this.y = y;
	}
	public void setZ(int z) {
		this.z = z;
	}
	public void setLocation(int location) {
		this.location = location;
	}
	public double getA() {
		return A;
	}
	public int getX() {
		return x;
	}
	public int getY() {  
		return y;
	}
	public int getZ() {
		return z;
	}
	public int getLocation() {
		return location;
	}
}

class Point{
	private int x;		//质点x坐标
	private int y;		//质点y坐标
	private int z;		//质点z坐标
	private int layer;	//质点所在第几层
	public Point() {
		super();
	}
	public Point(int x, int y, int z, int layer) {
		super();
		this.x = x;
		this.y = y;
		this.z = z;
		this.layer = layer;
	}

	public void setX(int x) {
		this.x = x;
	}
	public void setY(int y) {
		this.y = y;
	}
	public void setZ(int z) {
		this.z = z;
	}
	public void setLayer(int layer) {
		this.layer = layer;
	}
	public int getX() {
		return x;
	}
	public int getY() {
		return y;
	}
	public int getZ() {
		return z;
	}
	public int getLayer() {
		return layer;
	}
}
public class Ra {
	static Source so[]=new Source[Common.N];//存储源棒的数组
	static int loc[]=new int[Common.N];//存储源棒位置的临时数组
	static Point po[][]=new Point[Common.row][Common.col];		//存储质点的数组
	static double result1[][]=new double[Common.row][Common.col];	//存储第一个面上所有质点的能量
	static double result2[][]=new double[Common.row][Common.col];	//存储第二个面上所有质点的能量
	static double result3[][]=new double[Common.row][Common.col];	//存储第三个面上所有质点的能量
	static boolean temp[]=new boolean[Common.M];			//标志哪个位置还可以插源棒
	static double max,min;					//找出能量最大、最小的质点
	static double uniformity;
	/* 以源架平面的中心点为坐标原点建立三维直角坐标系,x轴为源架平面内水平方向,y轴为源架平面内上下方向,z轴为垂直源架平面方向。
	 * 装源所用空管分上下两层,间距20cm。每层有20个管,每个管的高度是45cm，管间距离5cm。各层分左右两区,各有10个管。
	 * 源架共有40个装源位置。从左向右、从上往下依次将编号为0，1、2、......37、38、39 。代表源棒所处位置
	 * 所以0号位置的管的x坐标为-50cm，y坐标为55cm，z坐标为0...依此类推
	*/
	//根据第i根源棒所处的位置loc求出对应的X、Y坐标
	public static void locWays(Source so[],int i,int loc){
		//loc表示源棒插在了哪个孔中（可取范围：0-39）
		//Common.zoneCount表示每区有10个管；Common.sgap表示管间距5cm；
		//Common.L表示管的长度45cm；Common.lgap表示上下两层之间的间距20cm
		if(loc<Common.zoneCount)
		{
			so[i].setX(loc*Common.sgap-Common.sgap*Common.zoneCount);
			so[i].setY(Common.L+Common.lgap/2);
		}else if(loc<(Common.zoneCount*2)&&loc>=Common.zoneCount){
		so[i].setX(loc*Common.sgap-Common.sgap*(Common.zoneCount-1));
		so[i].setY(Common.L+Common.lgap/2);
		}else if(loc<Common.zoneCount*3&&loc>=Common.zoneCount*2){
			so[i].setX(((loc-(Common.zoneCount*2))*Common.sgap)-Common.sgap*Common.zoneCount);
			so[i].setY(-(Common.lgap/2));
		}else{
			so[i].setX(((loc-(Common.zoneCount*2))*Common.sgap)-Common.sgap*(Common.zoneCount-1));
			so[i].setY(-(Common.lgap/2));
		}
		
	}
	//随机生成源棒的位置
	public static void sourceLocation()
	{
		Random ra=new Random();
		//源棒数组初始化 Common.N表示有16根源棒
		for(int i=0;i<Common.N;i++)
			so[i]=new Source();	
		//为每根棒设定能量
		so[0].setA(10893);
		so[1].setA(9342);
		so[2].setA(7010);
		so[3].setA(7340);
		so[4].setA(7700);
		so[5].setA(8102);
		so[6].setA(10023);
		so[7].setA(9763);
		so[8].setA(8321);
		so[9].setA(8675);
		so[10].setA(9012);
		so[11].setA(10342);
		so[12].setA(9428);
		so[13].setA(8910);
		so[14].setA(6820);
		so[15].setA(11099);
		for(int i=0;i<Common.N;i++)		//下标代表16根棒的序号
		{
			boolean flag=true;
			int loc=ra.nextInt(Common.M);	//随机生成源棒的位置（0-39）
			for(int j=0;j<i;j++)		//确保每个孔只插一根棒
			{
				if(so[j].getLocation()==loc)
				{
					i--;
					flag=false;
					break;
				}	
			}
			if(flag)						//该位置可插入源棒
			{
				temp[loc]=true;				//标志该位置已被占用
				so[i].setLocation(loc);
				locWays(so,i,loc);			//根据源棒位置loc确定第i根源棒的x、y坐标	
			}
		}
		for(int i=0;i<Common.N;i++)
			loc[i]=so[i].getLocation();
	}
	/* 确定被照物体在刚进入轨道第一个位置时第一个面上的所有质点的x、y、z坐标
	 * 其中Common.objectL表示物体的长度60cm，Common.objectH表示物体的高度200cm，Common.objectW表示物体的宽度40cm
	 * Common.pgap表示质点之间的间距为10cm，Common.ogap表示物体所处的位置之间的间距。
	 * 其中被照物体在轨道中所处的位置之间水平间距、垂直间距均为10cm，但是物体在第二次拐弯时的垂直间距为40，所以此时该平面在z=110cm处（40+40+10+20） 
	 */
    public static void pointLocation(){
		for(int i=0;i<Common.row;i++)
		{
			for(int j=0;j<Common.col;j++)
			{
				po[i][j]=new Point();		
				po[i][j].setX((Common.objectL*2+Common.pgap+Common.pgap/2)-j*Common.pgap);
				po[i][j].setY((Common.objectH/2)-i*Common.pgap);
				po[i][j].setLayer(0);		//第一个面上所有质点（共三个面0、1、2）
				po[i][j].setZ(Common.objectW*2+Common.ogap+Common.ogap*8);				
			}
		}	
	}
    //找出哪两个质点的能量值最大和最小，计算不均匀度
	public static double cal(){
		//Common.oloc表示物体总共可移动16次，move表示物体当前移动到的位置（0-15）
		for(int move=0;move<Common.oloc;move++)
		{
			//Common.N表示共有16根源棒
			for(int i=0;i<Common.N;i++)
			{
				int x0=so[i].getX();			//获取第i根源棒的x坐标
				int y0=so[i].getY();			//获取第i根源棒的y坐标
				for(int j=0;j<Common.row;j++)
				{					//j和k共同确定某一个质点
					for(int k=0;k<Common.col;k++)
					{
						int d=po[j][k].getZ();		//获取该质点的z坐标
						int x1=0;			//x1表示第一个面上的当前质点的x坐标减去源棒的x坐标
						
						/* 物体经过某两个位置时，质点的x坐标是相同的，比如0号位置和8号位置，1号位置和9号位置等
						 * 所以根据已经确定了的物体在第一个位置处第一个面上的所有质点的坐标来推出其他位置处质点的坐标
						 */							
						switch(move){
						case 0:
						case 8:
							x1=po[j][k].getX()-x0;break;
						case 1:
						case 9:
							//Common.objectL表示物体的宽度60cm
							//Common.ogap表示上一个位置距离下一个位置之间的水平间距10cm
							x1=po[j][k].getX()-Common.objectL-Common.ogap-x0;break;
						case 2:
						case 10:
							x1=po[j][k].getX()-Common.objectL*2-Common.ogap*2-x0;break;
						case 3:
						case 11:
							x1=po[j][k].getX()-Common.objectL*3-Common.ogap*3-x0;break;
						case 4:
						case 12:
							x1=-po[j][k].getX()-x0;break;
						case 5:
						case 13:
							x1=(Common.objectL+Common.ogap)-po[j][k].getX()-x0;break;
						case 6:
						case 14:
							x1=(Common.objectL*2-Common.ogap*2)-po[j][k].getX()-x0;break;
						case 7:
						case 15:
							x1=(Common.objectL*3-Common.ogap*3)-po[j][k].getX()-x0;break;
					
						}
						//a1表示第一个面上该质点与放射源棒的距离
						//a2表示第二个面上该质点与放射源棒的距离
						//a3表示第三个面上该质点与放射源棒的距离
						double a1=0,a2=0,a3=0;
						
						if((move<=3)||(move<=15&&move>=12)){
						a2=Math.sqrt((d-Common.objectW/2)*(d-Common.objectW/2)+x1*x1);
						a3=Math.sqrt((d-Common.objectW)*(d-Common.objectW)+x1*x1);}
						else if(move<=11){
							d=80;//该位置时第一个面距离z轴距离为50cm
							a2=Math.sqrt((d+Common.objectW/2)*(d+Common.objectW/2)+x1*x1);
							a3=Math.sqrt((d+Common.objectW)*(d+Common.objectW)+x1*x1);
						}
						a1=Math.sqrt(d*d+x1*x1);
						double b=po[j][k].getY()-y0;//质点的y坐标减去源棒的y坐标
						//当前位置下此根源棒对第一个面上该质点的能量值
						double ex1=(so[i].getA()/a1)*(Math.atan2(Common.L+b,a1)-Math.atan2(b,a1));
						//当前位置下此根源棒对第二个面上该质点的能量值
						double ex2=(so[i].getA()/a2)*(Math.atan2(Common.L+b,a2)-Math.atan2(b,a2));
						//当前位置下此根源棒对第三个面上该质点的能量值
						double ex3=(so[i].getA()/a3)*(Math.atan2(Common.L+b,a3)-Math.atan2(b,a3));
						//当开始循环下一根源棒或下一个位置时对同一个质点的能量值在此基础上相加
						result1[j][k]+=ex1;
						result2[j][k]+=ex2;	
						result3[j][k]+=ex3;	
						
					}
				}
			}
		}
		min=max=result1[0][0]; 
		//找出能量值最大和最小的质点
		
		for(int i=0;i<Common.row;i++)
		{
			for(int j=0;j<Common.col;j++)
			{
				if(result1[i][j]<min)
					min=result1[i][j];
				if(result1[i][j]>max)
					max=result1[i][j];
				if(result2[i][j]<min)
					min=result2[i][j];
				if(result2[i][j]>max)
					max=result2[i][j];
				if(result3[i][j]<min)
					min=result3[i][j];
				if(result3[i][j]>max)
					max=result3[i][j];
			}
			
		}
		
		//对该质点的能量值清零
		for(int j=0;j<Common.row;j++)
		{
			for(int k=0;k<Common.col;k++)
			{
				result1[j][k]=0;
				result2[j][k]=0;
				result3[j][k]=0;
			}
		}
		return max/min;
	}
	//对当前源棒找邻居
	public static boolean isLeft(Source so[],int i,int index){
		//从当前位置index的左边开始找，一直向左找，直到找到空位置就返回true
		for(int j=index-1;j>=0;j--)
		{
			if(!temp[j])
			{
				so[i].setLocation(j);
				return true;
			}
		}
		return false;
	}
	public static boolean isRight(Source so[],int i,int index){
		//从当前位置index的右边开始找，一直向右找，直到找到空位置就返回true
		for(int j=index+1;j<Common.M;j++)
		{
			if(!temp[j])
			{
				so[i].setLocation(j);
				return true;
			}
		}
		return false;
	}
	public static boolean isUpDown(Source so[],int i,int index){
		//找当前位置对应的下一层该位置处是否可用
		if(index>=0&&index<(Common.M/2)&&!temp[index+Common.M/2])
		{
			so[i].setLocation(index+Common.M/2);
			return true;
		}
		//找当前位置对应的上一层该位置处是否可用
		else if(index>=(Common.M/2)&&index<Common.M&&!temp[index-Common.M/2])
		{
			so[i].setLocation(index-Common.M/2);
			return true;
		}
		return false;
		
	}
	public static double localSearch(){
		//对随机生成的源棒的位置求一次不均匀度
		uniformity=cal();
		double tempValue;
		boolean isMove=true;
		//左右移动找一个最优值
		while(isMove){
			isMove=false;
			for(int i=0;i<Common.N;i++)
			{
				//对当前源棒找邻居，如果找到，就求不均匀度，如果值比原来大就舍弃，并且把源棒的坐标重新置为以前的坐标；如果和原来的相等或者比原来的值小就更新
				int index=so[i].getLocation();
				if(isLeft(so,i,index)){
					locWays(so,i,so[i].getLocation());
					tempValue=cal();
					if(tempValue<uniformity){
						uniformity=tempValue;
						isMove=true;
						temp[so[i].getLocation()]=true;
						temp[loc[i]]=false;
						loc[i]=so[i].getLocation();
					}else{
						so[i].setLocation(loc[i]);
						locWays(so,i,loc[i]);
					}	
				}
				if(isRight(so,i,index)){
					locWays(so,i,so[i].getLocation());
					tempValue=cal();
					if(tempValue<uniformity){
						uniformity=tempValue;
						isMove=true;
						temp[so[i].getLocation()]=true;
						temp[loc[i]]=false;
						loc[i]=so[i].getLocation();
					}else{
						so[i].setLocation(loc[i]);
						locWays(so,i,loc[i]);
					}	
				}
			}
		}
		//退出while循环 上下移动或者交换找一个最优
		for(int i=0;i<Common.N;i++){
			int index=so[i].getLocation();
			if(isUpDown(so, i, index)){	//如果可以上下移动
				locWays(so,i,so[i].getLocation());
				tempValue=cal();
				if(tempValue<=uniformity){
					uniformity=tempValue;
					temp[so[i].getLocation()]=true;
					temp[loc[i]]=false;
					loc[i]=so[i].getLocation();
				}else{
					so[i].setLocation(loc[i]);
					locWays(so,i,loc[i]);
				}	
			}else{	//上下不能移动时则交换
				if(index>=0&&index<(Common.M/2))
				{
					int loc1=index+Common.M/2;
					for(int j=0;j<Common.N;j++){
						if(so[j].getLocation()==loc1){
							so[j].setLocation(index);
							so[i].setLocation(loc1);
							locWays(so,i,so[i].getLocation());
							locWays(so,j,so[j].getLocation());
							tempValue=cal();
							if(tempValue<=uniformity){
								uniformity=tempValue;
								loc[i]=so[i].getLocation();
								loc[j]=so[j].getLocation();
							}else{
								so[i].setLocation(loc[i]);
								locWays(so,i,loc[i]);
								so[j].setLocation(loc[j]);
								locWays(so,j,loc[j]);
							}	
							break;
						}		
					}
				}else{
					int loc1=index-Common.M/2;
					for(int j=0;j<Common.N;j++){
						if(so[j].getLocation()==loc1){
							so[j].setLocation(index);
							so[i].setLocation(loc1);
							locWays(so,i,so[i].getLocation());
							locWays(so,j,so[j].getLocation());
							tempValue=cal();
							if(tempValue<=uniformity){
								uniformity=tempValue;
								loc[i]=so[i].getLocation();
								loc[j]=so[j].getLocation();
							}else{
								so[i].setLocation(loc[i]);
								locWays(so,i,loc[i]);
								so[j].setLocation(loc[j]);
								locWays(so,j,loc[j]);
							}	
							break;
						}		
					}
				}
			}
		}
		return uniformity;
	}
	
	static int r1,r2;
	public static boolean vibrate(){
		Random ra=new Random();
		r1=ra.nextInt(Common.N);
		r2=ra.nextInt(Common.N);
		while(r2==r1)
			r2=ra.nextInt(Common.N);
		int loc1=so[r1].getLocation();
		int loc2=so[r2].getLocation();
		if(isLeft(so, r1, loc1)){
			temp[so[r1].getLocation()]=true;
			temp[loc[r1]]=false;
			if(isLeft(so, r2, loc2)){
				temp[so[r2].getLocation()]=true;
				temp[loc[r2]]=false;
				loc[r1]=so[r1].getLocation();
				loc[r2]=so[r2].getLocation();
				locWays(so,r1,so[r1].getLocation());
				locWays(so,r2,so[r2].getLocation());
				return true;
			}else if(isRight(so, r2, loc2)){
				temp[so[r2].getLocation()]=true;
				temp[loc[r2]]=false;
				loc[r1]=so[r1].getLocation();
				loc[r2]=so[r2].getLocation();
				locWays(so,r1,so[r1].getLocation());
				locWays(so,r2,so[r2].getLocation());
				return true;
			}
		}else if(isRight(so, r1, loc1)){
			temp[so[r1].getLocation()]=true;
			temp[loc[r1]]=false;
			if(isLeft(so, r2, loc2)){
				temp[so[r2].getLocation()]=true;
				temp[loc[r2]]=false;
				loc[r1]=so[r1].getLocation();
				loc[r2]=so[r2].getLocation();
				locWays(so,r1,so[r1].getLocation());
				locWays(so,r2,so[r2].getLocation());
				return true;
			}else if(isRight(so, r2, loc2)){
				temp[so[r2].getLocation()]=true;
				temp[loc[r2]]=false;
				loc[r1]=so[r1].getLocation();
				loc[r2]=so[r2].getLocation();
				locWays(so,r1,so[r1].getLocation());
				locWays(so,r2,so[r2].getLocation());
				return true;
			}
		}
		return false;
	}
	public static void rwFile(double uniformity,double last){
		Date date = new Date(System.currentTimeMillis());  
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyyMMdd_HHmmss");  
        String fileName = dateFormat.format(date) + ".txt";
        FileWriter fw = null;
        try {
            fw = new FileWriter("E:\\"+fileName, true);
                fw.write("不均匀度:"+String.valueOf(uniformity)+"\r\n");
                String loc="";
                for(int i=0;i<16;i++)
                	loc+=so[i].getLocation()+",";
                fw.write("源棒的依次排列位置:"+loc+"\r\n");
                fw.write("程序运行时间："+String.valueOf(last/60.0)+"min");
                fw.flush();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            if (fw != null) {
                try {
                    fw.close();
                } catch (IOException e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                }
            }
        }
    }
	
	public static void main(String[] args){
		int loc1[]=new int[Common.N];
		double nonUniformity1;
		long startTime=System.currentTimeMillis();
		sourceLocation();//随机生成源棒的位置
		pointLocation();//确定被照物体在刚进入轨道第一个位置时第一个面上的所有质点的x、y、z坐标
		nonUniformity1=localSearch();
		boolean temp1[]=new boolean[Common.M];
		//System.out.println(nonUniformity1);
		//long end=System.currentTimeMillis();
		//System.out.println((end-startTime)/1000.0/60.0+"min");
		//for(int i=0;i<Common.N;i++)
			//System.out.print(so[i].getLocation()+",");
		for(int i=0;i<Common.N;i++)
			loc1[i]=so[i].getLocation();
		for(int i=0;i<Common.M;i++)
			temp1[i]=temp[i];
		double tempValue;
		int count=1;
		for(int i=0;i<200;i++){
			if(vibrate()){
				tempValue=localSearch();
				if(tempValue<=nonUniformity1){
					nonUniformity1=tempValue;
					count=1;
					/*for(int j=0;j<Common.N;j++)
						loc1[j]=so[j].getLocation();
					for(int j=0;j<Common.M;j++)
						temp1[j]=temp[j];*/
				}else
				{
					count++;
					/*for(int j=0;j<Common.M;j++)
						temp[j]=temp1[j];
					for(int j=0;j<Common.N;j++)
					{
						so[j].setLocation(loc1[j]);
						loc[j]=so[j].getLocation();
						locWays(so,j,loc[j]);
					}*/
				}
			}else
				count++;
			System.out.println("震荡到第"+i+"次");
			if(count>20)
				break;
		}
		long endTime=System.currentTimeMillis();
		double last=(endTime-startTime)/1000.0;
		rwFile(nonUniformity1, last);
		System.out.println("不均匀度："+nonUniformity1);
		System.out.println("源棒的排列位置：");
		for(int i=0;i<Common.N;i++)
			System.out.print(so[i].getLocation()+",");
		System.out.println();
		System.out.println("程序运行时间： "+last/60.0+"min");
		
		
	}


}
